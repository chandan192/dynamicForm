import { Component, OnInit, Input, SimpleChanges, OnChanges, ViewChild, QueryList, ElementRef, ViewChildren } from '@angular/core';
import { DynamicFormFields } from './../../../interfaces/dynamic-form';
import { FormGroup, FormControl, FormArray, Validators, ValidatorFn, ControlContainer } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DynamicFormService } from 'src/app/services/dynamic-form.service';

@Component({
  selector: 'app-json-array',
  templateUrl: './json-array.component.html',
  styleUrls: ['./json-array.component.css']
})
export class JsonArrayComponent implements OnInit, OnChanges {
  @Input() fields: DynamicFormFields;
  @Input() form: FormGroup;
  @ViewChildren('dialog') dialog: QueryList<ElementRef>;
  fieldData: DynamicFormFields;
  display: boolean;
  cols: { field: any; header: string; }[] = [];
  tableData: any[] = [];
  control: FormArray;
  selectedRow: any = {};
  wasPreviuosTableDataEmpty: boolean;
  editDisplay = false;
  selectedRecord: any[] = [];
  colspan: string;

  // tslint:disable-next-line: max-line-length
  constructor(private controlContainer: ControlContainer, private _snackBar: MatSnackBar, private dynamicFormService: DynamicFormService) { }

  ngOnInit() {

    this.dynamicFormService.getColSpan(this.fieldData.colspan).subscribe(result => {
      this.colspan = result;
    });

    for (const i of this.fieldData.fields) {
      this.cols.push({ field: i.key, header: i.label });
    }

    this.control = this.form.controls[this.fieldData.key] as FormArray;
    this.tableData = this.control.value;



  }

  ngOnChanges(changes: SimpleChanges) {
    this.fieldData = this.fields;
    // console.log('this.fieldData - fieldset', this.fieldData);
  }

  addControl() {
    this.selectedRow = {};
    this.dialog['_results'][this.dialog['_results'].length - 1].visible = false;

    if (this.wasPreviuosTableDataEmpty !== true) {
      this.control.push(
        this.toFormGroup(this.fieldData.fields)
      );
    }

    this.tableData = this.control.value;
  }

  deleteControl() {

    if (this.selectedRow.index == undefined) {
      this._snackBar.open('Please Select Row to Delete', 'OK', {
        duration: 3000
      });
      return;
    }
    this.control.removeAt(this.selectedRow.index);
    this.tableData = this.control.value;
    this.selectedRow = {};


  }

  editControl() {
    if (this.selectedRow.index == undefined) {
      this._snackBar.open('Please Select Row to Update', 'OK', {
        duration: 3000
      });
      return;
    }

    this.editDisplay = true;
    this.dialog['_results'][this.selectedRow.index].visible = true;

  }

  updateControl() {
    this.dialog['_results'][this.selectedRow.index].visible = false;

    this.tableData = this.control.value;
    this.selectedRow = {};
    this.editDisplay = false;

    // this.control.controls[this.selectedRow.index].patchValue(this.selectedRow.data);
  }

  resetUpdate() {
    this.dialog['_results'][this.selectedRow.index].visible = false;
    this.control.patchValue(this.tableData);

  }

  onRowSelect(event) {
    this.selectedRow = event;
  }

  onRowUnselect(event) {
    this.selectedRow = {};
  }


  showDialog() {
    console.log(this.dialog['_results'][this.dialog['_results'].length - 1]);

    this.dialog['_results'][this.dialog['_results'].length - 1].visible = true;

    if (!this.control.value.length) {
      this.wasPreviuosTableDataEmpty = true;
      this.control.push(
        this.toFormGroup(this.fieldData.fields)
      );
    }

    this.selectedRecord = this.control.value;


    // this.selectedRow = this.control.controls[this.control.value.length - 1].value;
  }

  resetControl() {
    this.dialog['_results'][this.dialog['_results'].length - 1].visible = false;

    this.control.patchValue(this.selectedRecord);

    // this.control.controls[this.control.controls.length - 1].patchValue(this.selectedRow);


  }

  toFormGroup(fields: DynamicFormFields[]) {
    const formControlMap = {};
    fields.forEach(field => {

      formControlMap[field.key] = new FormControl(field.value, this.generateValidator(field.validators));

    });
    return new FormGroup(formControlMap);

  }

  generateValidator(rule: any): ValidatorFn[] {
    const varray: ValidatorFn[] = [];
    // tslint:disable-next-line: forin
    for (const r in rule) {
      if (r === 'min') {
        varray.push(Validators.min(rule[r]));
      }
      if (r === 'max') {
        varray.push(Validators.max(rule[r]));
      }
      if (r === 'required') {
        varray.push(Validators.required);
      }
      if (r === 'requiredTrue') {
        varray.push(Validators.requiredTrue);
      }
      if (r === 'email') {
        varray.push(Validators.email);
      }
      if (r === 'minLength') {
        varray.push(Validators.minLength(rule[r]));
      }
      if (r === 'maxLength') {
        varray.push(Validators.maxLength(rule[r]));
      }
      if (r === 'pattern') {
        varray.push(Validators.pattern(rule[r]));
      }
    }
    return varray;
  }





}
