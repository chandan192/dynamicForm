import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { DynamicFormFields } from './../../../interfaces/dynamic-form';
import { FormGroup, ControlContainer } from '@angular/forms';
import { DynamicFormService } from './../../../services/dynamic-form.service';

@Component({
  selector: 'app-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.css']
})
export class SelectComponent implements OnInit, OnChanges {
  @Input() fields: DynamicFormFields;
  @Input() form: FormGroup;
  // form: FormGroup;
  fieldData: DynamicFormFields;
  options: any[];
  colspan: string;

  constructor(private controlContainer: ControlContainer, private dynamicFormService: DynamicFormService) { }

  ngOnInit() {
    this.dynamicFormService.getColSpan(this.fieldData.colspan).subscribe(result => {
      this.colspan = result;
    });
  }

  ngOnChanges() {
    this.fieldData = this.fields;
    if (typeof (this.fieldData.options) === 'string') {
      this.dynamicFormService.getMetadata(this.fieldData.options).subscribe(metadata => {
        this.options = metadata;
      });
    } else {
      this.options = this.fieldData.options;
    }

  }

}
