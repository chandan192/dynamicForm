import { Component, OnInit, Input, OnChanges, ViewChild, ViewContainerRef, ComponentFactoryResolver, AfterViewInit } from '@angular/core';
import { DynamicFormFields } from './../../../interfaces/dynamic-form';
import { DynamicFormService } from './../../../services/dynamic-form.service';

@Component({
  selector: 'app-custom',
  templateUrl: './custom.component.html',
  styleUrls: ['./custom.component.css']
})

export class CustomComponent implements OnInit, OnChanges {
  @Input() fields: DynamicFormFields;
  @ViewChild('container', { read: ViewContainerRef, static: false }) container: ViewContainerRef;

  // form: FormGroup;
  fieldData: DynamicFormFields;
  colspan: string;
  constructor(private componentFactoryResolver: ComponentFactoryResolver, private dynamicFormService: DynamicFormService) { }

  ngOnInit() {
    this.dynamicFormService.getColSpan(this.fieldData.colspan).subscribe(result => {
      this.colspan = result;
    });
  }

  ngOnChanges() {
    this.fieldData = this.fields;
    // console.log('this.fieldData : panel', this.fieldData);
  }

}
