import { Component, OnInit, Output, EventEmitter, Input, OnChanges } from '@angular/core';
import { DynamicFormService } from '../../services/dynamic-form.service';
import { FormGroup, ValidatorFn, Validators, FormControl, FormArray, AbstractControl } from '@angular/forms';
import { DynamicFormFields, DynamicForm, DynamicFormFieldsValidators } from '../../interfaces/dynamic-form';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.css']
})
export class DynamicFormComponent implements OnInit, OnChanges {
  @Output() result = new EventEmitter();
  @Input() panelPosition: string;
  @Input() jsonData: DynamicForm[];
  @Input() btnStyle: any;
  @Input() metadataMap: string;
  formSchema: DynamicForm[];
  form: FormGroup;

  constructor(private dynamicFormService: DynamicFormService, private router: Router) { }

  ngOnInit() {

  }

  generateValidator(rule: DynamicFormFieldsValidators): ValidatorFn[] {
    const varray: ValidatorFn[] = [];
    // tslint:disable-next-line: forin
    for (const r in rule) {
      if (r === 'min') {
        varray.push(Validators.min(rule[r]));
      }
      if (r === 'max') {
        varray.push(Validators.max(rule[r]));
      }
      if (r === 'required') {
        varray.push(Validators.required);
      }
      if (r === 'requiredTrue') {
        varray.push(Validators.requiredTrue);
      }
      if (r === 'email') {
        varray.push(Validators.email);
      }
      if (r === 'minLength') {
        varray.push(Validators.minLength(rule[r]));
      }
      if (r === 'maxLength') {
        varray.push(Validators.maxLength(rule[r]));
      }
      if (r === 'pattern') {
        varray.push(Validators.pattern(rule[r]));
      }
    }
    return varray;
  }

  toFormGroup(fields: any[]): FormGroup {
    const formControlMap = {};
    fields.forEach(field => {

      if (field.hasOwnProperty('formName')) {

        // if (field.fields.length) {
        formControlMap[field.formName] = this.toFormGroup(field.fields);
        // }

      } else if (field.controlType === 'json') {

        formControlMap[field.key] = this.toFormGroup(field.fields);

      } else if (field.controlType === 'jsonarray') {
        formControlMap[field.key] = new FormArray([this.toFormGroup(field.fields)]);
      } else {

        formControlMap[field.key] = new FormControl(field.value, this.generateValidator(field.validators));
      }

    });
    return new FormGroup(formControlMap);
  }


  onSubmit(f) {
    console.log('form : ', f);
    this.result.emit(f.value);

  }

  ngOnChanges() {
    this.formSchema = this.jsonData;
    this.form = this.toFormGroup(this.jsonData);
    this.dynamicFormService.setMetadata(this.metadataMap);
  }


}
