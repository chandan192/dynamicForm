import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { DynamicFormFields } from '../../interfaces/dynamic-form';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-dynamic-form-right',
  templateUrl: './dynamic-form-right.component.html',
  styleUrls: ['./dynamic-form-right.component.css']
})
export class DynamicFormRightComponent implements OnInit, OnChanges {
  @Input() fields: DynamicFormFields;
  @Input() form: FormGroup;
  // form: FormGroup;
  fieldData: DynamicFormFields;
  constructor() { }

  ngOnInit() {
  }

  ngOnChanges() {
    this.fieldData = this.fields;
    // console.log('this.fieldData : panel', this.fieldData);
  }

}
