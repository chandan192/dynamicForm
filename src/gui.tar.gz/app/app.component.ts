import { Component, OnInit } from '@angular/core';
import * as FormSchema from './data/dynamicForm.json';
import { DynamicForm } from './interfaces/dynamic-form.js';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'dataDrivenForm';
  sidePanelPosition = 'left';
  buttonStyle = { 'margin-left': '50%' };
  jsonFile: DynamicForm[] = FormSchema['default'];
  metadata = { pages: [{ label: 'sadsad', value: 'sad' }] };

  getResult(e) {
    console.log(e);
  }
}
