import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './routes/dynamicForm.routes';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { InputComponent } from './components/controlType/input/input.component';
import { ToggleComponent } from './components/controlType/toggle/toggle.component';
import { ChipsComponent } from './components/controlType/chips/chips.component';
import { MultiSelectComponent } from './components/controlType/multi-select/multi-select.component';
import { CalendarComponent } from './components/controlType/calendar/calendar.component';
import { PanelComponent } from './components/controlType/panel/panel.component';
import { DynamicFormComponent } from './components/dynamic-form/dynamic-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { JsonComponent } from './components/controlType/json/json.component';
import { JsonArrayComponent } from './components/controlType/json-array/json-array.component';
import { SelectComponent } from './components/controlType/select/select.component';
import { SliderComponent } from './components/controlType/slider/slider.component';
import { DynamicFormRightComponent } from './components/dynamic-form-right/dynamic-form-right.component';
import { CustomComponent } from './components/controlType/custom/custom.component';
import { DynamicComponentComponent } from './components/dynamic-component/dynamic-component.component';

// primeng
import { PanelModule } from 'primeng/panel';
import { CalendarModule } from 'primeng/calendar';
import { ChipsModule } from 'primeng/chips';
import { DropdownModule } from 'primeng/dropdown';
import { KeyFilterModule } from 'primeng/keyfilter';
import { MultiSelectModule } from 'primeng/multiselect';
import { SliderModule } from 'primeng/slider';
import { InputSwitchModule } from 'primeng/inputswitch';
import { TabViewModule } from 'primeng/tabview';
import { AccordionModule } from 'primeng/accordion';
import { DialogModule } from 'primeng/dialog';
import { TableModule } from 'primeng/table';

// material
import { MatSliderModule } from '@angular/material/slider';
import { MatSnackBarModule } from '@angular/material/snack-bar';




@NgModule({
  declarations: [
    AppComponent,
    InputComponent,
    ToggleComponent,
    ChipsComponent,
    MultiSelectComponent,
    CalendarComponent,
    PanelComponent,
    DynamicFormComponent,
    JsonComponent,
    JsonArrayComponent,
    SelectComponent,
    SliderComponent,
    DynamicFormRightComponent,
    CustomComponent,
    DynamicComponentComponent,

  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,

    // primeng
    PanelModule,
    CalendarModule,
    ChipsModule,
    DropdownModule,
    KeyFilterModule,
    MultiSelectModule,
    SliderModule,
    InputSwitchModule,
    TabViewModule,
    AccordionModule,
    DialogModule,
    TableModule,

    // material
    MatSliderModule,
    MatSnackBarModule


  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [DynamicComponentComponent]
})
export class AppModule { }
