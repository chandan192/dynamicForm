export class DynamicForm {
    constructor(
        public formName: string,
        public fields: any[],
        public description?: string,

    ) { }
}



export class DynamicFormFields {
    constructor(
        public key: string,
        public label: string,
        public value: string | number | boolean,
        public controlType: string,
        public fields: DynamicFormFields[],
        public description?: string,
        public options?: any[] | string,
        public type?: string,
        public unit?: string,
        public sequence?: number,
        public rowspan?: number,
        public colspan?: number,
        public style?: any,
        public styleClass?: string,
        public validators?: any,
        public dependency?: any[],
        public formName?: string

    ) { }
}

export class DynamicFormFieldsValidators {
    constructor(
        public min?: number,
        public max?: number,
        public required?: boolean | { key: string, value: string, exist: boolean }[],
        public email?: string,
        public pattern?: string
    ) { }
}


